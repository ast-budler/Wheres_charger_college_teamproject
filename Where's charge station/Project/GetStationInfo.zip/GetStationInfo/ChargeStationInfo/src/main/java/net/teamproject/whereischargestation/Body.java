package net.teamproject.whereischargestation;

import java.util.List;

public class Body {
	List<Item> items;
	
	
	public List<Item> getItems() {
		return items;
	}
	public void setItems(List<Item> items) {
		this.items = items;
	}
}
