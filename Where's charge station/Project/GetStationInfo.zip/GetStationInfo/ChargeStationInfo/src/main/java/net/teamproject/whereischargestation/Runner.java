package net.teamproject.whereischargestation;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

public class Runner {
	final static String uri = "http://apis.data.go.kr/B552584/EvCharger/getChargerInfo"
			+ "?serviceKey=aRHWU5VcuL6kz4%2FxQQOXJKRuFShw%2F%2BVzm5HDJPnzJMgFJ2csEnSN4SlxfY3owIoxK6lrN5pDFPcYhe2zpEqMQA%3D%3D"
			+ "&numOfRows=10&pageNo=1";
	
	
	public static void main(String[] args) {
		HttpClient client = HttpClientBuilder.create().build();
		HttpGet req = new HttpGet(uri);
		HttpResponse res;
		
		try {
			File file = new File("C:\\Temp\\ChargeStationInfo.txt");
			BufferedWriter writer = new BufferedWriter(new FileWriter(file));
			res = client.execute(req);
			
			if(res.getStatusLine().getStatusCode() == 200) {
				String body = EntityUtils.toString(res.getEntity(), "UTF-8");
				
				ObjectMapper mapper = new XmlMapper();
				
				Response result = mapper.readValue(body, Response.class);
				
				for(Item item : result.getBody().getItems()) {
					writer.write(item.toString() + "\n");
				}
				writer.close();
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
}