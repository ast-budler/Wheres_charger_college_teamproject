package net.teamproject.whereischargestation.service;

public class RootService {

}
