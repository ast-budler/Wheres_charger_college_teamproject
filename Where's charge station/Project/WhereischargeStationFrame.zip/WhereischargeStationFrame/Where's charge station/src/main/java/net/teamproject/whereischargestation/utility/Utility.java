package net.teamproject.whereischargestation.utility;

public class Utility {

}
