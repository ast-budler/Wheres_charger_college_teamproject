package net.teamproject.whereischargestation.dao;

public class RootDao {

}
