package net.teamproject.whereischargestation.service.module;

public class ServiceModule {

}
