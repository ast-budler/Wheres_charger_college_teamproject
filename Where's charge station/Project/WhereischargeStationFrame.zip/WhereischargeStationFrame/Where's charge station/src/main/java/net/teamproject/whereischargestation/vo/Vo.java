package net.teamproject.whereischargestation.vo;

public class Vo {

}
